/*
 * DataCache.hpp
 *
 *  Created on: May 8, 2016
 *      Author: yupeng
 */

#ifndef INCLUDE_DATACACHE_HPP_
#define INCLUDE_DATACACHE_HPP_

#include "DataCache.h"

/*
 * destructor
 */
DataCache::~DataCache() {

}

#endif /* INCLUDE_DATACACHE_HPP_ */
