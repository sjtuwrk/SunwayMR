/*
 * MessageType.hpp
 *
 *  Created on: Dec 10, 2015
 *      Author: yupeng
 */

#ifndef MESSAGETYPE_HPP_
#define MESSAGETYPE_HPP_

#include "MessageType.h"

#endif /* MESSAGETYPE_HPP_ */

