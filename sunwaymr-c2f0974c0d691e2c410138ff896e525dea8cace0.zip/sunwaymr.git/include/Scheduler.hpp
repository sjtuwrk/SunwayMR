/*
 * Scheduler.hpp
 *
 *  Created on: Dec 5, 2015
 *      Author: shi qiuwei
 */

#ifndef SCHEDULER_HPP_
#define SCHEDULER_HPP_


#include "Scheduler.h"

Scheduler::Scheduler() {

}

Scheduler::~Scheduler() {

}

#endif /* SCHEDULER_HPP_ */

